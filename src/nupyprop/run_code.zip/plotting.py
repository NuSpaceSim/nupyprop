import numpy as np
import pandas as pd
import h5py
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

# --- inputs ---
#H5_PATH = "/Users/luke/Research/nupyprop_vec2/nupyprop/tutorial/data/output_nu_tau_4km_ct18nlo_allm_prem_stochastic_1e8.h5"
H5_PATH = "output_nu_tau_0km_ct18nlo_allm_stochastic_1e7.h5"
ENERGY_KEY = "10.0"  # log10(E/GeV) key inside the H5
#CSV_PATH = "10_pexit_no_regen_test.csv"  # update if your csv filename differs
CSV_PATH = "pexit_batched_10_0km.csv"

# --- load old/reference from H5 ---
with h5py.File(H5_PATH, "r") as f:
    p = f["Exit_Probability"][ENERGY_KEY]

    # dataset rows are (angle_deg, p_no_regen, p_regen)
    arr = np.asarray([(ang, p_no, p_reg) for (ang, p_no, p_reg) in p], dtype=float)

angles_h5 = arr[:, 0]
p_no_h5   = arr[:, 1]
p_reg_h5  = arr[:, 2]

# --- load vectorized results from CSV ---
df = pd.read_csv(CSV_PATH)

# accept either naming convention if you've changed it
if "angle_deg" in df.columns:
    angles_csv = df["angle_deg"].to_numpy(float)
else:
    angles_csv = df["angle"].to_numpy(float)

if "p_no_regen" in df.columns:
    p_no_csv = df["p_no_regen"].to_numpy(float)
else:
    p_no_csv = df["p_no_regen"].to_numpy(float) if "p_no_regen" in df.columns else df["p_no_regen"].to_numpy(float)

# regen column may be named p_regen or p_no_regen_test style
if "p_regen" in df.columns:
    p_reg_csv = df["p_regen"].to_numpy(float)
elif "p_exit_regen" in df.columns:
    p_reg_csv = df["p_exit_regen"].to_numpy(float)
else:
    raise KeyError("CSV must contain a regen column named 'p_regen' (or 'p_exit_regen').")

# --- make sure arrays are float ---
angles_h5 = np.asarray(angles_h5, dtype=float)
p_no_h5   = np.asarray(p_no_h5, dtype=float)
p_reg_h5  = np.asarray(p_reg_h5, dtype=float)

angles_csv = np.asarray(angles_csv, dtype=float)
p_no_csv   = np.asarray(p_no_csv, dtype=float)
p_reg_csv  = np.asarray(p_reg_csv, dtype=float)
p_reg_csv = p_no_csv + p_reg_csv

# --- find common angles for residuals (robust to float formatting) ---
angles_h5_r  = np.round(angles_h5,  6)
angles_csv_r = np.round(angles_csv, 6)

common, idx_h5, idx_csv = np.intersect1d(angles_h5_r, angles_csv_r, return_indices=True)

if common.size == 0:
    raise RuntimeError("No common angles found between H5 and CSV.")

angles_common = common

p_no_h5_common  = p_no_h5[idx_h5]
p_no_csv_common = p_no_csv[idx_csv]

p_reg_h5_common  = p_reg_h5[idx_h5]
p_reg_csv_common = p_reg_csv[idx_csv]

# residuals (relative)
res_no_rel  = (p_no_h5_common  - p_no_csv_common)  / p_no_csv_common
res_reg_rel = (p_reg_h5_common - p_reg_csv_common) / p_reg_csv_common

# --- plots ---
fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True, figsize=(7.5, 8.5), constrained_layout=True)

ax1.set_title(r"$p_{exit}$ at $10^{10}$ GeV (no-regen solid, regen dashed)")

# x ticks for log axis
xticks = [0.1, 1, 2, 3, 5, 8, 10, 20, 30]
ax1.set_xticks(xticks)
ax1.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, pos: f"{x:g}"))

# Vectorized (CSV)
ax1.plot(angles_csv, p_no_csv, marker="o", linestyle="-",  label="Vec no-regen")
ax1.plot(angles_csv, p_reg_csv, marker="o", linestyle="--", label="Vec regen")

# Old/reference (H5)
ax1.plot(angles_h5, p_no_h5,  linestyle="-",  label="Old no-regen")
ax1.plot(angles_h5, p_reg_h5, linestyle="--", label="Old regen")

ax1.set_yscale("log")
ax1.set_xscale("log")
ax1.set_ylabel("p_exit")
ax1.grid(True, which="both", alpha=0.3)
ax1.legend()

# residuals
ax2.axhline(0.0, linewidth=1)
ax2.plot(angles_common, res_no_rel,  marker="o", linestyle="-",  label="(Old - Vec) / Vec  no-regen")
ax2.plot(angles_common, res_reg_rel, marker="o", linestyle="--", label="(Old - Vec) / Vec  regen")

ax2.set_xscale("log")
ax2.set_xlabel(r"$\beta_{tr}$ [degrees]")
ax2.set_ylabel("relative residual")
ax2.grid(True, which="both", alpha=0.3)
ax2.legend()

plt.show()
plt.close()
