import matplotlib.pyplot as plt
import pandas as pd

file10 = 'pexit_no_regen.csv'

data = pd.read_csv(file10, header=None)

print(data)