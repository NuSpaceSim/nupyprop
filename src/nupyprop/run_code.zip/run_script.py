from nupyprop.main import main
import time
import csv
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


if __name__ == "__main__":
    # --- Benchmark settings ---
    E_prop = [10]  # log10(GeV) energies
    angles = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,2,3,4,5]

    batch_stats = int(1e7)   # stats per batch
    n_batches = 1         # number of batches per angle

    # --- Physics/config settings (match your normal runs) ---
    kwargs = dict(
        nu_type="neutrino",
        cross_section_model="ct18nlo",
        pn_model="allm",
        earth_model="prem",
        idepth=0,
        ch_lepton="tau",
        fac_nu=1.0,
        prop_type="stochastic",
        elep_mode="yes",
        htc_mode="no",
    )

    total_stats = batch_stats * n_batches
    print(f"Benchmark (batched in main): {n_batches} batches x {batch_stats:,} stats per batch per angle")
    print(f"Total stats per angle: {total_stats:,}\n")

    t0 = time.perf_counter()

    # One call; batching happens inside main per angle.
    results_nr, results_r, e_out_by_key = main(
        E_prop=E_prop,
        angles=angles,
        stats=total_stats,  # not used when batch_stats is set; kept for compatibility
        batch_stats=batch_stats,
        n_batches=n_batches,
        **kwargs,
    )


    print("type(e_out_by_key):", type(e_out_by_key))
    print("keys (sample):", list(e_out_by_key.keys())[:4])
    print("first few results_nr:", results_nr[:3], " ... last:", results_nr[-1])
    print("first few results_r :", results_r[:3],  " ... last:", results_r[-1])
    ### energy cdf try ###
#    print(len(results_nr), len(e_out))
#    df_eout = pd.DataFrame({'Energy' : e_exit})
#    df_eout.to_csv('10_01.csv', index=False)

# ---------------- Exiting tau energy spectra (overlay) ----------------
# Note: e_out uses 0 as a sentinel meaning "no exiting tau".

# Common log-spaced bins across angles
    emin, emax = 1e5, 1e11
    bins = np.logspace(np.log10(emin), np.log10(emax), 40)

    # Linestyles to match legacy comparison plots
    style_map = {
        1: ":",     # dotted
        10: "-.",   # dash-dot
        20: "--",   # dashed
        30: "-",    # solid
    }

    plt.figure()

    # e_out_by_key is keyed by (log10E, angle_deg)
    energy_key = float(E_prop[0])

    for ang in angles:
        e_out_ang = np.asarray(e_out_by_key[(energy_key, float(ang))])
        e_exit = e_out_ang[e_out_ang > 0]  # drop non-exits (sentinel 0)
        if e_exit.size == 0:
            print(f"WARNING: no exiting taus for angle={ang} deg")
            continue

        counts, edges = np.histogram(e_exit, bins=bins)
        scaled = counts / counts.max() if counts.max() > 0 else counts

        ls = style_map.get(int(ang), "-")
        plt.step(edges[:-1], scaled, where="post", linestyle=ls, label=rf"{ang}$^\circ$")

    plt.xscale("log")
    plt.xlabel(r"$E_\tau$ [GeV]")
    plt.ylabel(r"Scaled $N_\tau$")
    plt.ylim(0, 1.2)
    plt.legend(title=r"$\beta_{\rm tr}$")
    plt.title(rf"$\log_{{10}}(E_\nu/\mathrm{{GeV}})={E_prop[0]:.2f}$")
    plt.tight_layout()
    plt.savefig('energy_cdf_0km.pdf', dpi = 800)

    t_list = []
    t1 = time.perf_counter()
    print(f"\nTotal wall time: {t1 - t0:.2f} s")
    #t_list.append(t1 - t0)
    t_list = [0.85,12.21,35.18,65.01,92.67,105.94,100.98,102.19,108.44,109.05]
    angles = [0.1,1,2,3,5,10,15,25,35,40]
    plt.plot(angles,t_list)
    plt.grid(True)
    plt.title('Runtime per angle for 10^10 GeV, for 1e6 stats')
    plt.ylim([0,110])
    plt.xlabel('Angle')
    plt.ylabel('Runtime (s)')
    plt.savefig('runtime_0km_1e6.pdf', dpi=800)

    # --- write results to CSV for plotting.py ---
    # main() returns lists of (angle_deg, p) tuples
    nr_map = {float(a): float(p) for a, p in results_nr}
    r_map = {float(a): float(p) for a, p in results_r}

    # preserve the angle order you requested in this script
    angles_out = [float(a) for a in angles]

    out_path = "pexit_batched_10_0km.csv"
    with open(out_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["angle_deg", "p_no_regen", "p_regen"])
        for a in angles_out:
            w.writerow([a, nr_map.get(a, ""), r_map.get(a, "")])

    print(f"Wrote CSV: {out_path}")
